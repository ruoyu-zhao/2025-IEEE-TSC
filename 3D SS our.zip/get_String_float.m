function processed_matrix=get_String_float(matrix_float,begin_i,end_i)
%对浮点数进行分割，每一行是一个顶点，每一列是一个系数,得到的是string类型
processed_matrix=string(zeros(size(matrix_float,1),3));
for i=1:1:3%三个系数
    t_cor_index=matrix_float(:,begin_i:end_i);%提取
    matrix_float=matrix_float(:,33:end);%剔除
    processed_matrix(:,i)=string(t_cor_index);
end