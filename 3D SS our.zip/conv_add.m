function result=conv_add(x1,x2)%两个数值相加，它们都是十进制
x1=gf_to_num(x1);
x2=gf_to_num(x2);
%%%%%%%bitxor只支持数值
result=bitxor(x1,x2);
