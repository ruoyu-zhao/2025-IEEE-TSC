function huifu=main_huifu(x_matrix,y_matrix,multb,invtb)

m=size(x_matrix,2);
[threshold,len]=size(y_matrix);%每一个块有多长


subBlock_num=len/m;


huifu=[];
for i=1:1:subBlock_num
    subBlock=y_matrix(:,1:m);%子块
    t_result=Shamir_huifu(x_matrix,subBlock,multb,invtb);

    y_matrix=y_matrix(:,m+1:end);%去除掉已经用掉的子块

    huifu=[huifu,t_result];
end




