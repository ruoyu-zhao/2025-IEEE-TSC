%function yj=Shamir_Share(a,p,xj)

function yj=Shamir_Share(a,xj,multi_table)
m=size(a,2);
ori_result=Poly_multi(a,xj,multi_table);%Eq（8） ，结果是十进制

bin_result = de2bi(ori_result, 'left-msb');%二进制数组
length_bin=length(bin_result);

yj=[zeros(1,m-length_bin),bin_result];




% m=size(a,2);% 
% ori_result=Poly_multi(a,xj);%Eq（8） 
% 
% %有限域求模：https://www.cnblogs.com/yupence/p/16491011.html
% [~,remainder_coeffs]=deconv(ori_result,p);%还需要截取
% t_remainder_coeffs=remainder_coeffs(end-m+1:end);%截取，但系数可能为负数，求模
% yj=mod(t_remainder_coeffs,2);%结果