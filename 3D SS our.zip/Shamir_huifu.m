%x矩阵,它的维度是threshold*m;mutlb乘法表;invtb逆元表
function result=Shamir_huifu(x_matrix,y_matrix,multb,invtb)

m=size(x_matrix,2);%有多少列

dec_result=Lag(x_matrix,y_matrix,multb,invtb);

bin_result = de2bi(dec_result, 'left-msb');%二进制数组
length_bin=length(bin_result);

result=[zeros(1,m-length_bin),bin_result];



