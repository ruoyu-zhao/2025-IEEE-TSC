
%它是一个矩阵，x坐标和y坐标对应的是两个数相乘，值是正对角线对称的
function result=Gen_multi_table(m,prim_poly)

els = gf([1:2^m-1]',m,prim_poly);%不包括0
result = els * els';%%%%%乘法表，正表