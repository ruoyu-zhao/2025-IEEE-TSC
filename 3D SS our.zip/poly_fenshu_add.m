function [fenzi_poly,fenmu_poly]=poly_fenshu_add(fenzi1,fenmu1,fenzi2,fenmu2)
%a/b、c/d; fenzi=ad+bc; fenmu=bd
fenzi_poly=poly_add(conv(fenzi1,fenmu2),conv(fenzi2,fenmu1));
fenmu_poly=conv(fenmu1,fenmu2);

