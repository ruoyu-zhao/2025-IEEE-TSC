function frac=Compute_frac(index_matrix,alp_matrix,begin_point)

[x,y]=size(alp_matrix);
frac=zeros(x,y);%小数
for i=1:1:x
    for j=1:1:y
        t_alp=alp_matrix(i,j);
        t_pure_fra=getfractional(char(t_alp),begin_point);

        t_index=char(index_matrix(i,j));
        exp=pow2((bin2dec(t_index)-127));%指数
        if exp==-127%非规格化数
            exp=-126;
        end

        frac(i,j)=t_pure_fra*exp;%小数
    end

end