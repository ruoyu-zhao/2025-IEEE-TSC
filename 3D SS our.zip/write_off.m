function write_off(newname,line_2,vertexs,faces)
%写入文件

% 创建一个新文件
fid = fopen(newname, 'w');

line_1='OFF';

fprintf(fid, '%c', line_1);
fprintf(fid, '\n');

fprintf(fid, '%d ', line_2);
fprintf(fid, '\n');
 
fprintf(fid, '%g %g %g\n', vertexs');
% for i=1:1:size(vertexs,1)
%     fprintf(fid, '%f ', vertexs(i,:));
%     fprintf(fid, '\n');
% end


for i=1:1:size(faces,1)
    fprintf(fid, '%d ', faces(i,:));
    fprintf(fid, '\n');
end

fclose(fid);

