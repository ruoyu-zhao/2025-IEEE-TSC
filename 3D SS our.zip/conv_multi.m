function result=conv_multi(x1,x2,multi_table)%两个多项式相乘,x1和x2假定为十进制

x1=gf_to_num(x1);
x2=gf_to_num(x2);

mod_x=size(multi_table,1)+1;%2^m

%在域内求模
x1_mod=mod(x1,mod_x);
x2_mod=mod(x2,mod_x);

if x1_mod==0 || x2_mod==0
    result=0;
else
    result=multi_table(x1_mod,x2_mod);

end


