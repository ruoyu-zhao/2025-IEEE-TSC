%把gf类型的数据转为数值

function result=gf_to_num(x)

if isa(x,'gf')
    result=x.x;%从gf中提取数值
else
    result=x;
end
