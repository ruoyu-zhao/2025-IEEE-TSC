
%它是一行，下标对应的是多项式，值对应的是逆元
function result=Gen_inver_table(multi_table)

len=size(multi_table,1);%1~11111 

inv_table=zeros(1,len);

for i=1:1:len
    t_arry=multi_table(i,:);%提取出乘法表的第i行，以便寻找逆元1
    t_xiabiao=find(t_arry(:)==1);
    inv_table(1,i)=t_xiabiao;
end

result=inv_table;

