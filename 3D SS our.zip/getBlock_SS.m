function block=getBlock_SS(alp_matrix,begin_point,alp)
%%%得到块

x_alp=char(alp_matrix(:,1));
y_alp=char(alp_matrix(:,2));
z_alp=char(alp_matrix(:,3));




% t_block=[x_alp(:,begin_point:begin_point+alp-1) y_alp(:,begin_point:begin_point+alp-1) z_alp(:,begin_point:begin_point+alp-1)];%提取出属于这个块的alp

t_block=[x_alp y_alp z_alp];%提取出属于这个块的alp

t_block_zhuanzhi=t_block';
line_block_zhuanzhi=t_block_zhuanzhi(:)';%变成一行顺序是 顶点(x,y,z)->顶点(x,y,z)

block=line_block_zhuanzhi;
