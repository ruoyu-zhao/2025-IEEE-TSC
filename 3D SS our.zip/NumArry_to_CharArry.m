function char_bitstream=NumArry_to_CharArry(binary_array)
%把0 1数组，转化为char比特流

% 将逻辑数组转换为数字数组
numeric_array = double(binary_array);

% 将数字数组转换为字符数组
char_bitstream = char(numeric_array + '0');