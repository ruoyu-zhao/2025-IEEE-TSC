%读取off文件的顶点和面
function [vertexs,faces,n3]=read_off_v_f(offname)%offname文件名
fid=fopen(offname);%读取文件

str = fgets(fid);   % -1 if eof
str1 = fgets(fid); %打开第二行

[a1,str2] = strtok(str1);
nvert = str2num(a1);%顶点的个数

[a2,str3] = strtok(str2); 
nface = str2num(a2);%面的个数

[a3,str4] = strtok(str3); 
n3 = str2num(a3);%第三个格式的个数


size_vertex=[3 nvert];
vertexs = fscanf(fid,'%f %f %f',size_vertex);

size_face=[4 nface];
faces=fscanf(fid,'%d %d %d %d\n', size_face);

vertexs=vertexs';
faces=faces';

fclose(fid);