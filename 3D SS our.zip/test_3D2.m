offname='wan.off';%文件名
alp=2;%alpha
m=alp*3;
begin_point=1;%从左到右数

[~,pure_name,~]=fileparts(offname);

threshold = 3; 
shareNum = 3; 

G=gfprimfd(m,'all',2);%伽罗华域
ori_p=G(1,:);%它的系数是从小到大排列的,升序
p=fliplr(ori_p);%反转，降序
prim_poly=bi2de(p,'left-msb');%本原多项式，十进制



% [main_y,sub_ori_vex]=Share_block(m,shareNum,threshold,vertexs,prim_poly,alp,begin_point);
multb=Gen_multi_table(m,prim_poly);%乘法表
invtb=Gen_inver_table(multb);%逆元表


x_matrix=Gen_xmatrix(shareNum,m);%x_matrix 有shareNum行

[vertexs,faces,n3] =  read_off_v_f(offname);%顶点和面数 每一行是一个坐标构成

line_2=[size(vertexs,1),size(faces,1),n3];%off文件的第二行

matrix_float=getFloat(vertexs);%得到32位浮点数,一行是一个顶点。1~32是x的，33~64是y的，65~96是z的

[index_matrix,alp_matrix]=fenge_Float(matrix_float,begin_point,alp);%对浮点数进行分割
frac=Compute_frac(index_matrix,alp_matrix,begin_point);%计算出小数，以去处理原始的顶点矩阵,index_matirx是指数位
sub_ori_vex=Subtraction_frac(vertexs,frac);%减去小数，
%%%%上面是参数准备

%%%%%%%%%秘密共享

block=getBlock_SS(alp_matrix,begin_point,alp);%得到块

main_y=main_fenxiang(block,threshold,shareNum,x_matrix,multb);%每一行都是要分享的块

%
%构建 要分享的3D object
% tic
for i=1:1:shareNum
    t_block=main_y(i,:);
    enc_bitstream=NumArry_to_CharArry(t_block);%%%%秘密分享得到的块（比特流）
    enc_vertex=Synthetic_vertex(enc_bitstream,sub_ori_vex,begin_point,index_matrix,alp);

    en_name=[pure_name,'_',num2str(shareNum),'_Share_',num2str(i),'_alp_',num2str(alp),'_begin_',num2str(begin_point),'.off',];
    write_off(en_name,line_2,enc_vertex,faces);%写解密文件

end
% t1=toc



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% i=1;
% en_offname=['Share_',num2str(i),'_alp_',num2str(alp),'_',offname];%文件名
% 
% [en_vertexs,faces,n3] =  read_off_v_f(en_offname);%顶点和面数 每一行是一个坐标构成
% 
% line_2=[size(en_vertexs,1),size(faces,1),n3];%off文件的第二行
% 
% en_matrix_float=getFloat(en_vertexs);%得到32位浮点数,一行是一个顶点。1~32是x的，33~64是y的，65~96是z的
% 
% [en_index_matrix,en_alp_matrix]=fenge_Float(en_matrix_float,begin_point,alp);%对浮点数进行分割
% 
% en_frac=Compute_frac(en_index_matrix,en_alp_matrix,begin_point);%计算出小数，以去处理原始的顶点矩阵,index_matirx是指数位
% sub_en_vex=Subtraction_frac(en_vertexs,en_frac);%减去小数
% 
% en_block=getBlock_SS(en_alp_matrix,begin_point,alp);%得到块，是char类型
% 
% Num_en_block=en_block-'0';%把char转化为数组
% 
% t_tiqu=main_y(i,:);
% 
% indices = find(t_tiqu ~= Num_en_block)
% isequal(Num_en_block,t_tiqu) %测试是否能够从分享的3D object正确取出数值


%%%%%%%解密参数准备



%%%%%%%%%秘密共享进行恢复%%%%%%
fenxiang_y=main_y(1:3,:);%要分享的块


huifu=main_huifu(x_matrix,fenxiang_y,multb,invtb);%%%数组形式

huifu_bitstream=NumArry_to_CharArry(huifu);%%%%秘密分享得到的块（比特流）


%%%%合成顶点%%%%%%%%%%%%%%%%%%%%%%%%
% tic
% dec_vertex=Synthetic_vertex(huifu_bitstream,sub_ori_vex,begin_point,index_matrix,alp);
% t2=toc
% 
% de_name=['touxiang_shibai_(4,5)','_alp_',num2str(alp),'_',offname];
% write_off(de_name,line_2,dec_vertex,faces);%写解密文件


