function  sub_ori_vex=Add_frac(vertexs,frac)
%符号矩阵
sign_matrix=vertexs;
sign_matrix(sign_matrix>=0)=1;
sign_matrix(sign_matrix<0)=-1;

unsign_vex=abs(vertexs);%绝对值

unsign_sub_vex=unsign_vex+frac;%减去小数

sub_ori_vex=unsign_sub_vex.*sign_matrix;%附上符号


