% 定义包含 0 和 1 的数字数组
binary_array = [0, 1, 0, 1, 1];

% 将逻辑数组转换为数字数组
numeric_array = double(binary_array);

% 将数字数组转换为字符数组
char_bitstream = char(numeric_array + '0');

% 显示结果
disp(char_bitstream);