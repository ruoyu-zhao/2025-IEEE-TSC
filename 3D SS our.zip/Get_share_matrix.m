function alp_matrix=Get_share_matrix(block,alp)
%block是一行
%alp_matrix的维度是vex*3.每一行代表一个顶点
per_vex_blo_num=alp*3;%每个顶点在块中alp的数量,因为有3个顶点所以*3
bit_num=size(block,2);%有多少列，也就是多少bit

vex_num= bit_num/per_vex_blo_num;%顶点的数量
alp_matrix=string(zeros(vex_num,3));%每一行是一个顶点，每一列是顶点的一个系数(x,y,z)

t_block=line2matrix(block,vex_num,per_vex_blo_num);%得到一个矩阵，每一行都是一个顶点的alp(x,y,z顺序)

x_block=t_block(:,1:alp);
y_block=t_block(:,alp+1:2*alp);
z_block=t_block(:,2*alp+1:3*alp);

alp_matrix(:,1)=string(x_block);
alp_matrix(:,2)=string(y_block);
alp_matrix(:,3)=string(z_block);