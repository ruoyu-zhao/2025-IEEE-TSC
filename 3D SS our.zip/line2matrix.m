function matrix=line2matrix(line,row_num,column_num)
%以行的顺序，把line转化为一个矩阵

matrix=transpose(reshape(line,column_num,row_num));