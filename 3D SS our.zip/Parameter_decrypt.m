function Num_en_block=Parameter_decrypt(i,offname,begin_point,alp)

%结果是数组

en_offname=['Share_',num2str(i),'_alp_',num2str(alp),'_',offname];%文件名

[en_vertexs,faces,n3] =  read_off_v_f(en_offname);%顶点和面数 每一行是一个坐标构成

line_2=[size(en_vertexs,1),size(faces,1),n3];%off文件的第二行

en_matrix_float=getFloat(en_vertexs);%得到32位浮点数,一行是一个顶点。1~32是x的，33~64是y的，65~96是z的

[en_index_matrix,en_alp_matrix]=fenge_Float(en_matrix_float,begin_point,alp);%对浮点数进行分割

en_frac=Compute_frac(en_index_matrix,en_alp_matrix,begin_point);%计算出小数，以去处理原始的顶点矩阵,index_matirx是指数位
sub_en_vex=Subtraction_frac(en_vertexs,en_frac);%减去小数

en_block=getBlock_SS(en_alp_matrix,begin_point,alp);%得到块，是char类型

Num_en_block=en_block-'0';%把char转化为数组