%block是一行向量
%subblock尺寸是m*subBlock_num，每一列是一个子块
function subblock=Get_subblock(block,m)

subBlock_num=length(block)/m;%子块的数量


char_matrix=reshape(block,m,subBlock_num);%尺寸是m*subBlock_num，以列的顺序进行

subblock=char_matrix-'0';%把char转化为数组