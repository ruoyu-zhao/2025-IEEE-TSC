function vertex=Synthetic_vertex(huifu_bitstream,sub_ori_vex,begin_point,index_matrix,alp)

%huifu_bitstream是块
%sub_ori_vex是减去小数的顶点
%begin_point 开始点
%index_matrix 指数矩阵 2~9
%alp 长度

%%%%合成块
dec_alp_matrix=block2alpmatrix(huifu_bitstream,alp);%由块得到alp_matrix

dec_frac=Compute_frac(index_matrix,dec_alp_matrix,begin_point);%计算出小数，以加在顶点矩阵上

dec_vex=Add_frac(sub_ori_vex,dec_frac);%合成顶点

vertex=dec_vex;