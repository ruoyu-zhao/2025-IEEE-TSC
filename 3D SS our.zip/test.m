
l=2;

m=l*3;%长度

t_s = [1,1,1,1,1,1]; % the secret number
threshold = 4; 
shareNum = 4; 


G=gfprimfd(m,'all',2);%伽罗华域
ori_p=G(1,:);%它的系数是从小到大排列的,升序
p=fliplr(ori_p);%反转，降序
prim_poly=bi2de(p,'left-msb');%本原多项式，十进制

multb=Gen_multi_table(m,prim_poly);%乘法表
invtb=Gen_inver_table(multb);%逆元表

rng(1);
a_ori=randi([0,1],threshold-1 ,m);%随机生成一个矩阵，代表参数a
a=[t_s;a_ori];%把a0放在第一个位置上,a有threshold行

x_matrix=Gen_xmatrix(shareNum,m);%x_matrix 有shareNum行

y_matrix=zeros(shareNum,m);%y_matrix 有shareNum行

for i=1:1:shareNum
    y_matrix(i,:)=Shamir_Share(a,x_matrix(i,:),multb);
end


%%%%%%%%%%%恢复

%恢复
x_matrix=x_matrix(1:threshold,:);%只需要threshold的数据
result=Shamir_huifu(x_matrix,y_matrix,multb,invtb);%恢复的数据



isequal(result,t_s);
