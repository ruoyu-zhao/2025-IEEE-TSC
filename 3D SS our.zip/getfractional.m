function fra=getfractional(block_mas,begin_point)%block_mas块的数值
alpha=size(block_mas,2);
t=begin_point;

fra=0;
for i=1:1:alpha
if str2num(block_mas(1,i))==1
    fra=fra+(0.5)^(t);
end
t=t+1;
end


