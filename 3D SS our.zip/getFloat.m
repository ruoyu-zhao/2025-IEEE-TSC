function matrix_float=getFloat(vertexs)%得到32位浮点数
%1~32是x的，33~64是y的，65~96是z的
vertexs=single(vertexs);%确保是32位浮点数

n=size(vertexs,1);%x=顶点的数量
matrix_float=[];
for i=1:1:n
    single_vert=vertexs(i,:);
    t_binvert=[];
    for j=1:1:3
        t_cor=single_vert(1,j);%顶点的一个系数
        t_bin=float2bin(t_cor);%转化为32位浮点数
        t_binvert=[t_binvert t_bin];%一个顶点

%         %测试
%         t_float=bin2float(t_bin)
%         if t_float ~= t_cor
% 
%            fprintf('错误 (i,j)=%d,%d \n',i,j)
% 
%         end

    end
    matrix_float=[matrix_float;t_binvert];%一行是一个顶点。1~32是x的，33~64是y的，65~96是z的
end
