function alp_matrix=block2alpmatrix(block,alp)
%block的每一行都是一个块。该函数的目的是把块变成alp矩阵,对应于gerbloack函数

per_vex_blo_num=alp*3;%每个顶点在每个块中alp的数量
bit_num=size(block,2);%块有多少列

vex_num= bit_num/per_vex_blo_num;%顶点的数量
alp_matrix=string(zeros(vex_num,3));%每一行是一个顶点，每一列是顶点的一个系数(x,y,z)


    line_block_zhuanzhi=block;
    t_block=line2matrix(line_block_zhuanzhi,vex_num,per_vex_blo_num);%得到一个矩阵，每一行都是一个顶点的alp(x,y,z顺序)
    
    x_t_block=t_block(:,1:alp);
    y_t_block=t_block(:,alp+1:2*alp);
    z_t_block=t_block(:,2*alp+1:3*alp);


alp_matrix(:,1)=string(x_t_block);
alp_matrix(:,2)=string(y_t_block);
alp_matrix(:,3)=string(z_t_block);
