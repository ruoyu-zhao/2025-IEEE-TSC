function x_matrix=Gen_xmatrix(shareNum,m)
%x_matrix矩阵有shareNum行，每一行有m个元素
x_matrix=zeros(shareNum,m);

for i=1:1:shareNum

    row=randi([0,1],1,m);

    % 生成非全为零的随机二进制行
    while all(row == 0)
        row = randi([0 1], 1, m); % 生成一个随机的二进制行
    end

    % 检查新生成的行是否与之前的行都不相同
    while any(ismember(x_matrix(1:i-1,:),row,"rows"))
         row = randi([0 1], 1, m); % 重新生成一个随机的二进制行
    end

    x_matrix(i,:)=row;


end

