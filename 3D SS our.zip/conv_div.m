%x1是分子，x2是分母，除法就相当于x1乘以x2的逆元
%x1和x2都是整数
function result=conv_div(x1,x2,multb,invtb)

x1=gf_to_num(x1);
x2=gf_to_num(x2);

x2_div=invtb(1,x2);

result=conv_multi(x1,x2_div,multb);