function result=Lag(x_matrix,y_matrix,multb,invtb)
threshold=size(y_matrix,1);%阈值，y是有几个参与者，每一行都是它们的数据


result=0;
for i=1:1:threshold
    xi=x_matrix(i,:);
    xi_dec=bi2de(xi,'left-msb');%十进制

    yi=y_matrix(i,:);
    yi_dec=bi2de(yi,'left-msb');%十进制
    la=1;%lag

    for j=1:1:threshold

        if i~=j
            xj=x_matrix(j,:);
            xj_dec=bi2de(xj,'left-msb');%十进制
            t_fenmu=conv_add(xj_dec,xi_dec);%减法就是加法
            t_la=conv_div(xj_dec,t_fenmu,multb,invtb);
            la=conv_multi(t_la,la,multb);%连乘
        end
    end
    %连乘结束，需要乘以yi
    Li=conv_multi(yi_dec,la,multb);%yi*la(x),相当于关于yi的基函数

    result=conv_add(Li,result);   

end