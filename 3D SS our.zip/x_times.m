function results=x_times(x_dec,i,multi_table)%x代表多项式，i代表几次方

results=x_dec;
%十进制
for k=2:1:i
    results=conv_multi(results,x_dec,multi_table);
end
% if i==0%x的零次方是0
%     results=1;
% else
%     results=x;
%     for k=2:1:i
%         results=conv(results,x);%多项式相乘
%     end
% end