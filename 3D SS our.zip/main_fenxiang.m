function main_y=main_fenxiang(block,threshold,shareNum,x_matrix,multb)
%main_y的每一行都是一个share，尺寸是shareNum*len

%m代表2^m,main_y的每一行是一个要分享的块，尺寸是shareNum*len；每个子块的长度是m
len=length(block);

m=size(x_matrix,2);


subblock=Get_subblock(block,m);%subblock尺寸是m*subBlock_num，每一列是一个子块
subBlock_num=length(block)/m;%子块的数量

main_y=zeros(shareNum,len);%分享的块

for i=1:1:shareNum
    t=[];
    for j=1:1:subBlock_num

        rng(1);
        a_ori=randi([0,1],threshold-1 ,m);%随机生成一个矩阵，代表参数a

        t_s=subblock(:,j)';%提取出第j个子块，需要对其转置

        


        a=[t_s;a_ori];%把a0放在第一个位置上,a有threshold行

        
        
        t_y=Shamir_Share(a,x_matrix(i,:),multb);
        t=[t,t_y];
    end

    main_y(i,:)=t;

end
