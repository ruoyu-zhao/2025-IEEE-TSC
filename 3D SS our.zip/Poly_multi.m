function result=Poly_multi(a,x,multi_table)
%a是矩阵，x是向量（xi）


threshold=size(a,1);%a的行 即代表threshold

s_dec=bi2de(a(1,:),'left-msb');%十进制 a0
x_dec=bi2de(x,'left-msb');%十进制 xi
for i=2:1:threshold
    xn=x_times(x_dec,i-1,multi_table);%x的次方,xn是十进制
    a_dec=bi2de(a(i,:),'left-msb');%十进制
    t=conv_multi(a_dec,xn,multi_table);%a*x^(i-1) Eq(8),结果是十进制
    s_dec=conv_add(t,s_dec);
end
result=s_dec;
