function [index_matrix,alp_matrix]=fenge_Float(matrix_float,begin_point,alp)
%index_matrix,alp_matrix都为string类型，每一行是一个顶点，每一列是一个系数
begin_point=9+begin_point;
index_matrix=get_String_float(matrix_float,2,9);
alp_matrix=get_String_float(matrix_float,begin_point,begin_point+alp-1);%把块提取出来
